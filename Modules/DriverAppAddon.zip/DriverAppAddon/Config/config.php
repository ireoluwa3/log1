<?php

return [
    'name' => 'DriverAppAddon',

    'permissions' => [

        'driver-app-addon' => [
            'settings',
        ],
    ]
];
