<?php

return [
    'name' => 'CustomerAppAddon',

    'permissions' => [

        'driver-app-addon' => [
            'settings',
        ],
    ]
];
